import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuthAsync } from '@/lib/auth';
import { handleAuthError } from '@/lib/api-errors';

// P0.11 backup import hardening:
//   - Strict version check: backup.version === 3
//   - Validate ownership of every FK reference (accountId, categoryId, toAccountId)
//     before creating the transaction → closes IDOR
//   - Regenerate all primary keys (strip client-supplied IDs) — defense in depth
//   - Validate currency + type enums per row
//   - Bounded row counts (max 50000 transactions per backup)
//   - Don't leak err.message to client

const BACKUP_VERSION = 3;
const MAX_ROWS = 50000;

// GET /api/backup?action=export - user-scoped
export async function GET(req: NextRequest) {
  try {
    const userId = await requireAuthAsync(req);
    const [accounts, categories, transactions, budgets] = await Promise.all([
      db.account.findMany({ where: { userId } }),
      db.category.findMany({ where: { userId } }),
      db.transaction.findMany({ where: { userId }, include: { account: true, category: true } }),
      db.budget.findMany({ where: { userId } }),
    ]);

    const backup = {
      version: BACKUP_VERSION,
      app: 'mywallet',
      exportedAt: new Date().toISOString(),
      data: {
        // P0.11: export WITHOUT primary keys — on import, fresh cuids are generated.
        // This prevents a malicious backup from setting arbitrary PKs.
        accounts: accounts.map(({ name, type, currency, balance, color, icon, isDefault, createdAt, updatedAt }) =>
          ({ name, type, currency, balance, color, icon, isDefault, createdAt, updatedAt })),
        categories: categories.map(({ nameAr, nameEn, type, icon, color, isDefault, createdAt, updatedAt }) =>
          ({ nameAr, nameEn, type, icon, color, isDefault, createdAt, updatedAt })),
        transactions: transactions.map(({ type, amount, currency, date, note, tags, transferPairId, createdAt, updatedAt }) =>
          ({ type, amount, currency, date, note, tags, transferPairId, createdAt, updatedAt })),
        budgets: budgets.map(({ month, limit, currency, createdAt, updatedAt }) =>
          ({ month, limit, currency, createdAt, updatedAt })),
      },
    };

    return new NextResponse(JSON.stringify(backup, null, 2), {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="mywallet-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    });
  } catch (err: any) {
    return handleAuthError(err);
  }
}

// POST /api/backup?action=import - user-scoped, ATOMIC, with IDOR defense
export async function POST(req: NextRequest) {
  try {
    const userId = await requireAuthAsync(req);
    const formData = await req.formData();
    const file = formData.get('file') as File;
    if (!file) return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });

    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: 'File too large (max 10MB)' }, { status: 400 });
    }

    const text = await file.text();
    let backup;
    try {
      backup = JSON.parse(text);
    } catch {
      return NextResponse.json({ error: 'Invalid JSON file' }, { status: 400 });
    }

    // P0.11: strict version check (was: truthy check that accepted v1, v999, "foo", etc.)
    if (typeof backup?.version !== 'number' || backup.version !== BACKUP_VERSION) {
      return NextResponse.json(
        { error: `Unsupported backup version (expected ${BACKUP_VERSION}). Please export a fresh backup first.` },
        { status: 400 },
      );
    }
    if (!backup?.data || typeof backup.data !== 'object') {
      return NextResponse.json({ error: 'Invalid backup format - missing data' }, { status: 400 });
    }

    const { accounts = [], categories = [], transactions = [], budgets = [] } = backup.data;

    // P0.11: row count limits
    if (transactions.length > MAX_ROWS || accounts.length > 1000 || categories.length > 1000 || budgets.length > 1000) {
      return NextResponse.json({ error: `Backup exceeds row limits (max ${MAX_ROWS} transactions, 1000 each for accounts/categories/budgets)` }, { status: 400 });
    }

    // ATOMIC: delete old + restore new (with regenerated IDs + FK ownership validation)
    const result = await db.$transaction(async (tx) => {
      await tx.transaction.deleteMany({ where: { userId } });
      await tx.budget.deleteMany({ where: { userId } });
      await tx.account.deleteMany({ where: { userId } });
      await tx.category.deleteMany({ where: { userId } });

      let catCount = 0, accCount = 0, txCount = 0, budCount = 0;

      // Insert categories with FRESH IDs (Prisma auto-generates cuid).
      // Map old ID → new ID so transactions can resolve categoryId.
      const categoryIdMap = new Map<string, string>();
      for (const c of categories) {
        // Validate category type enum (allow EXPENSE, INCOME, TRANSFER for legacy)
        if (!['EXPENSE', 'INCOME', 'TRANSFER'].includes(c.type)) {
          throw new Error(`Invalid category type: ${c.type}`);
        }
        const created = await tx.category.create({
          data: {
            nameAr: String(c.nameAr || '').slice(0, 200),
            nameEn: String(c.nameEn || '').slice(0, 200),
            type: c.type,
            icon: String(c.icon || 'tag').slice(0, 100),
            color: String(c.color || '#10B981').slice(0, 20),
            isDefault: Boolean(c.isDefault),
            userId,
          },
        });
        if (c.id) categoryIdMap.set(c.id, created.id);
        catCount++;
      }

      const accountIdMap = new Map<string, string>();
      const VALID_ACCOUNT_TYPES = new Set(['CASH', 'BANK', 'E_WALLET', 'CARD', 'SAVINGS', 'INVESTMENT', 'LOAN', 'EXTERNAL']);
      const VALID_CURRENCIES = new Set(['EGP', 'SAR', 'USD', 'EUR', 'AED']);
      for (const a of accounts) {
        if (!VALID_ACCOUNT_TYPES.has(a.type)) {
          throw new Error(`Invalid account type: ${a.type}`);
        }
        if (!VALID_CURRENCIES.has(a.currency)) {
          throw new Error(`Invalid currency: ${a.currency}`);
        }
        // P0.11: validate balance is finite (no NaN/Infinity)
        const bal = Number(a.balance);
        if (!Number.isFinite(bal)) {
          throw new Error('Account balance must be a finite number');
        }
        const created = await tx.account.create({
          data: {
            name: String(a.name || '').slice(0, 200),
            type: a.type,
            currency: a.currency,
            balance: bal,
            color: String(a.color || '#2563EB').slice(0, 20),
            icon: String(a.icon || 'wallet').slice(0, 100),
            isDefault: Boolean(a.isDefault),
            userId,
          },
        });
        if (a.id) accountIdMap.set(a.id, created.id);
        accCount++;
      }

      // P0.11: IDOR defense — for each imported transaction, verify the FK
      // references resolve to accounts/categories OWNED BY THIS USER
      // (which they now are, because we just inserted them above).
      // If an old ID doesn't appear in our map → reject that row (skipped).
      for (const t of transactions) {
        // Resolve the foreign keys through our idMap.
        // If the source ID is missing → cross-user reference attempt → skip.
        const newAccountId = t.accountId ? accountIdMap.get(t.accountId) : undefined;
        const newCategoryId = t.categoryId ? categoryIdMap.get(t.categoryId) : undefined;
        const newToAccountId = t.toAccountId ? accountIdMap.get(t.toAccountId) : undefined;

        if (!newAccountId || !newCategoryId) {
          // P0.11: skip rows whose FK references can't be resolved to the user's own data.
          // This blocks the IDOR attack where a malicious backup references another user's account.
          continue;
        }

        // Validate transaction type + currency
        if (!['EXPENSE', 'INCOME', 'TRANSFER'].includes(t.type)) {
          continue;
        }
        if (!VALID_CURRENCIES.has(t.currency)) {
          continue;
        }

        const amt = Number(t.amount);
        if (!Number.isFinite(amt)) {
          continue;
        }

        await tx.transaction.create({
          data: {
            type: t.type,
            amount: amt,
            currency: t.currency,
            accountId: newAccountId,
            categoryId: newCategoryId,
            toAccountId: newToAccountId || null,
            date: new Date(t.date),
            note: t.note ? String(t.note).slice(0, 500) : null,
            tags: t.tags ? String(t.tags).slice(0, 200) : null,
            transferPairId: t.transferPairId ? String(t.transferPairId).slice(0, 50) : null,
            userId,
          },
        });
        txCount++;
      }

      for (const b of budgets) {
        const newCategoryId = b.categoryId ? categoryIdMap.get(b.categoryId) : undefined;
        if (!newCategoryId) continue;
        if (!VALID_CURRENCIES.has(b.currency)) continue;
        if (!/^\d{4}-\d{2}$/.test(b.month)) continue;
        const lim = Number(b.limit);
        if (!Number.isFinite(lim) || lim < 0) continue;

        await tx.budget.create({
          data: {
            categoryId: newCategoryId,
            month: b.month,
            limit: lim,
            currency: b.currency,
            userId,
          },
        });
        budCount++;
      }

      return { accounts: accCount, categories: catCount, transactions: txCount, budgets: budCount };
    });

    return NextResponse.json({ success: true, imported: result });
  } catch (err: any) {
    return handleAuthError(err);
  }
}
